# Databricks notebook source
# DBTITLE 1,Parse PDFs from Volume and Create Bronze Table
# Databricks Notebook - PDF to Bronze Processing
# Reads PDFs from Unity Catalog volume and creates Bronze tables with parsed content

# ============================================================
# CONFIGURATION
# ============================================================

# Source path for PDF files
SOURCE_VOLUME_PATH = "/Volumes/aichatbot/raw/pdf_files"

# Target catalog and schema for Bronze tables
TARGET_CATALOG = "aichatbot"
TARGET_SCHEMA = "bronze"
TARGET_TABLE = "handbook_pdf_parsed"

# Full table name
FULL_TABLE_NAME = f"{TARGET_CATALOG}.{TARGET_SCHEMA}.{TARGET_TABLE}"

print(f"✅ Configuration loaded")
print(f"   Source: {SOURCE_VOLUME_PATH}")
print(f"   Target: {FULL_TABLE_NAME}")

# COMMAND ----------

# DBTITLE 1,Parse PDFs and Create Bronze Table
# MAGIC %sql
# MAGIC -- ============================================================
# MAGIC -- PARSE PDFs AND CREATE BRONZE TABLE
# MAGIC -- ============================================================
# MAGIC -- This reads all PDFs from the source volume, parses them using
# MAGIC -- AI functions, and stores the results in a Bronze table
# MAGIC
# MAGIC CREATE OR REPLACE TABLE aichatbot.bronze.handbook_pdf_parsed AS
# MAGIC SELECT
# MAGIC   -- File metadata
# MAGIC   path,
# MAGIC   length AS file_size_bytes,
# MAGIC   modificationTime AS file_modified_at,
# MAGIC   
# MAGIC   -- Parse the PDF content
# MAGIC   ai_parse_document(
# MAGIC     content,
# MAGIC     MAP('version', '2.0')
# MAGIC   ) AS parsed_content,
# MAGIC   
# MAGIC   -- Processing metadata
# MAGIC   current_timestamp() AS processed_at
# MAGIC   
# MAGIC FROM read_files(
# MAGIC   '/Volumes/aichatbot/raw/pdf_files',
# MAGIC   format => 'binaryFile'
# MAGIC )
# MAGIC WHERE lower(path) LIKE '%.pdf';
# MAGIC
# MAGIC -- Show success message
# MAGIC SELECT 'Bronze table created successfully!' AS status;

# COMMAND ----------

# DBTITLE 1,Verify Bronze Table Content
# MAGIC %sql
# MAGIC -- ============================================================
# MAGIC -- VERIFY BRONZE TABLE
# MAGIC -- ============================================================
# MAGIC -- Check the parsed results and filter out any errors
# MAGIC
# MAGIC SELECT
# MAGIC   path,
# MAGIC   file_size_bytes,
# MAGIC   CASE 
# MAGIC     WHEN try_cast(parsed_content:error_status AS STRING) IS NULL THEN 'Success'
# MAGIC     ELSE 'Error: ' || try_cast(parsed_content:error_status AS STRING)
# MAGIC   END AS parse_status,
# MAGIC   array_size(try_cast(parsed_content:document:pages AS ARRAY<VARIANT>)) AS num_pages,
# MAGIC   array_size(try_cast(parsed_content:document:elements AS ARRAY<VARIANT>)) AS num_elements,
# MAGIC   processed_at
# MAGIC FROM aichatbot.bronze.handbook_pdf_parsed
# MAGIC ORDER BY path;

# COMMAND ----------

# DBTITLE 1,Summary Statistics
# MAGIC %sql
# MAGIC -- ============================================================
# MAGIC -- SUMMARY STATISTICS
# MAGIC -- ============================================================
# MAGIC
# MAGIC SELECT
# MAGIC   COUNT(*) AS total_files,
# MAGIC   SUM(CASE WHEN try_cast(parsed_content:error_status AS STRING) IS NULL THEN 1 ELSE 0 END) AS successful_parses,
# MAGIC   SUM(CASE WHEN try_cast(parsed_content:error_status AS STRING) IS NOT NULL THEN 1 ELSE 0 END) AS failed_parses,
# MAGIC   SUM(array_size(try_cast(parsed_content:document:pages AS ARRAY<VARIANT>))) AS total_pages,
# MAGIC   ROUND(AVG(file_size_bytes) / 1024 / 1024, 2) AS avg_file_size_mb,
# MAGIC   ROUND(SUM(file_size_bytes) / 1024 / 1024, 2) AS total_size_mb
# MAGIC FROM aichatbot.bronze.handbook_pdf_parsed;