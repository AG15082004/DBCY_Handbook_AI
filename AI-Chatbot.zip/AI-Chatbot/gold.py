# Databricks notebook source
# DBTITLE 1,Configuration
# ============================================================
# GOLD LAYER - FACT & DIMENSION TABLES CONFIGURATION
# ============================================================

from pyspark.sql.functions import monotonically_increasing_id, row_number, lit
from pyspark.sql.window import Window

# Source configuration
SILVER_TABLE = "aichatbot.silver.handbook_cleaned"
BRONZE_TABLE = "aichatbot.bronze.handbook_pdf_parsed"

# Target schema
GOLD_CATALOG = "aichatbot"
GOLD_SCHEMA = "gold"

print(f"✅ Configuration loaded")
print(f"   Source Silver: {SILVER_TABLE}")
print(f"   Source Bronze: {BRONZE_TABLE}")
print(f"   Target: {GOLD_CATALOG}.{GOLD_SCHEMA}")
print(f"\n📊 Creating Star Schema with:")
print(f"   - Dimension Tables: Documents, Element Types, Dates")
print(f"   - Fact Tables: Document Metrics, Element Details")

# COMMAND ----------

# DBTITLE 1,Dimension Table: dim_document
# MAGIC %sql
# MAGIC -- ============================================================
# MAGIC -- DIMENSION TABLE: dim_document
# MAGIC -- ============================================================
# MAGIC -- Contains document master data and metadata
# MAGIC
# MAGIC CREATE OR REPLACE TABLE aichatbot.gold.dim_document (
# MAGIC   document_key INT COMMENT 'Surrogate key for document',
# MAGIC   document_name STRING COMMENT 'Name of the document file',
# MAGIC   document_path STRING COMMENT 'Full path to the document',
# MAGIC   total_pages INT COMMENT 'Total number of pages in the document',
# MAGIC   file_type STRING COMMENT 'File extension/type',
# MAGIC   source_system STRING COMMENT 'Source system identifier',
# MAGIC   is_active BOOLEAN COMMENT 'Is this document currently active',
# MAGIC   created_date TIMESTAMP COMMENT 'When the document was first loaded',
# MAGIC   updated_date TIMESTAMP COMMENT 'When the document was last updated'
# MAGIC ) COMMENT 'Dimension table containing document metadata'
# MAGIC TBLPROPERTIES ('quality' = 'gold', 'layer' = 'dimension');
# MAGIC
# MAGIC -- Populate dim_document
# MAGIC INSERT OVERWRITE TABLE aichatbot.gold.dim_document
# MAGIC SELECT
# MAGIC   ROW_NUMBER() OVER (ORDER BY document_name) AS document_key,
# MAGIC   document_name,
# MAGIC   path AS document_path,
# MAGIC   total_pages,
# MAGIC   REGEXP_EXTRACT(document_name, '\\.([^.]+)$', 1) AS file_type,
# MAGIC   'aichatbot.bronze' AS source_system,
# MAGIC   TRUE AS is_active,
# MAGIC   bronze_processed_at AS created_date,
# MAGIC   silver_processed_at AS updated_date
# MAGIC FROM aichatbot.silver.handbook_cleaned;
# MAGIC
# MAGIC SELECT * FROM aichatbot.gold.dim_document;

# COMMAND ----------

# DBTITLE 1,Dimension Table: dim_element_type
# MAGIC %sql
# MAGIC -- ============================================================
# MAGIC -- DIMENSION TABLE: dim_element_type
# MAGIC -- ============================================================
# MAGIC -- Contains element type classifications
# MAGIC
# MAGIC CREATE OR REPLACE TABLE aichatbot.gold.dim_element_type (
# MAGIC   element_type_key INT COMMENT 'Surrogate key for element type',
# MAGIC   element_type_code STRING COMMENT 'Code identifier for element type',
# MAGIC   element_type_name STRING COMMENT 'Descriptive name for element type',
# MAGIC   element_category STRING COMMENT 'Category grouping (Content, Structure, Metadata)',
# MAGIC   is_content_bearing BOOLEAN COMMENT 'Does this element contain meaningful content',
# MAGIC   sort_order INT COMMENT 'Display sort order'
# MAGIC ) COMMENT 'Dimension table for PDF element types'
# MAGIC TBLPROPERTIES ('quality' = 'gold', 'layer' = 'dimension');
# MAGIC
# MAGIC -- Populate dim_element_type with reference data
# MAGIC INSERT OVERWRITE TABLE aichatbot.gold.dim_element_type
# MAGIC VALUES
# MAGIC   (1, 'text', 'Text Content', 'Content', TRUE, 1),
# MAGIC   (2, 'table', 'Table', 'Content', TRUE, 2),
# MAGIC   (3, 'figure', 'Figure/Image', 'Content', TRUE, 3),
# MAGIC   (4, 'section_header', 'Section Header', 'Structure', TRUE, 4),
# MAGIC   (5, 'title', 'Title', 'Structure', TRUE, 5),
# MAGIC   (6, 'caption', 'Caption', 'Structure', TRUE, 6),
# MAGIC   (7, 'page_header', 'Page Header', 'Metadata', FALSE, 7),
# MAGIC   (8, 'page_footer', 'Page Footer', 'Metadata', FALSE, 8),
# MAGIC   (9, 'page_number', 'Page Number', 'Metadata', FALSE, 9),
# MAGIC   (10, 'footnote', 'Footnote', 'Content', TRUE, 10);
# MAGIC
# MAGIC SELECT * FROM aichatbot.gold.dim_element_type ORDER BY sort_order;

# COMMAND ----------

# DBTITLE 1,Dimension Table: dim_date
# MAGIC %sql
# MAGIC -- ============================================================
# MAGIC -- DIMENSION TABLE: dim_date
# MAGIC -- ============================================================
# MAGIC -- Date dimension for time-based analysis
# MAGIC
# MAGIC CREATE OR REPLACE TABLE aichatbot.gold.dim_date (
# MAGIC   date_key INT COMMENT 'Surrogate key in YYYYMMDD format',
# MAGIC   full_date DATE COMMENT 'Full date value',
# MAGIC   year INT COMMENT 'Year',
# MAGIC   quarter INT COMMENT 'Quarter (1-4)',
# MAGIC   month INT COMMENT 'Month (1-12)',
# MAGIC   month_name STRING COMMENT 'Month name',
# MAGIC   week_of_year INT COMMENT 'Week of year',
# MAGIC   day_of_month INT COMMENT 'Day of month',
# MAGIC   day_of_week INT COMMENT 'Day of week (1=Monday, 7=Sunday)',
# MAGIC   day_name STRING COMMENT 'Day name',
# MAGIC   is_weekend BOOLEAN COMMENT 'Is weekend day'
# MAGIC ) COMMENT 'Date dimension for time-based analysis'
# MAGIC TBLPROPERTIES ('quality' = 'gold', 'layer' = 'dimension');
# MAGIC
# MAGIC -- Populate dim_date with dates from processing timestamps
# MAGIC INSERT OVERWRITE TABLE aichatbot.gold.dim_date
# MAGIC SELECT DISTINCT
# MAGIC   CAST(DATE_FORMAT(date_value, 'yyyyMMdd') AS INT) AS date_key,
# MAGIC   date_value AS full_date,
# MAGIC   YEAR(date_value) AS year,
# MAGIC   QUARTER(date_value) AS quarter,
# MAGIC   MONTH(date_value) AS month,
# MAGIC   DATE_FORMAT(date_value, 'MMMM') AS month_name,
# MAGIC   WEEKOFYEAR(date_value) AS week_of_year,
# MAGIC   DAYOFMONTH(date_value) AS day_of_month,
# MAGIC   DAYOFWEEK(date_value) AS day_of_week,
# MAGIC   DATE_FORMAT(date_value, 'EEEE') AS day_name,
# MAGIC   CASE WHEN DAYOFWEEK(date_value) IN (1, 7) THEN TRUE ELSE FALSE END AS is_weekend
# MAGIC FROM (
# MAGIC   SELECT CAST(bronze_processed_at AS DATE) AS date_value FROM aichatbot.silver.handbook_cleaned
# MAGIC   UNION
# MAGIC   SELECT CAST(silver_processed_at AS DATE) AS date_value FROM aichatbot.silver.handbook_cleaned
# MAGIC   UNION
# MAGIC   SELECT CURRENT_DATE() AS date_value
# MAGIC );
# MAGIC
# MAGIC SELECT * FROM aichatbot.gold.dim_date ORDER BY date_key;

# COMMAND ----------

# DBTITLE 1,Fact Table: fact_document_metrics
# MAGIC %sql
# MAGIC -- ============================================================
# MAGIC -- FACT TABLE: fact_document_metrics
# MAGIC -- ============================================================
# MAGIC -- Main fact table with document-level metrics
# MAGIC
# MAGIC CREATE OR REPLACE TABLE aichatbot.gold.fact_document_metrics (
# MAGIC   fact_key BIGINT COMMENT 'Surrogate key for fact record',
# MAGIC   document_key INT COMMENT 'Foreign key to dim_document',
# MAGIC   processing_date_key INT COMMENT 'Foreign key to dim_date',
# MAGIC   
# MAGIC   -- Metrics/Measures
# MAGIC   total_pages INT COMMENT 'Total number of pages',
# MAGIC   total_elements BIGINT COMMENT 'Total number of elements extracted',
# MAGIC   total_content_length BIGINT COMMENT 'Total character count of content',
# MAGIC   avg_content_length_per_element INT COMMENT 'Average content length per element',
# MAGIC   avg_content_length_per_page DOUBLE COMMENT 'Average content length per page',
# MAGIC   
# MAGIC   -- Processing metadata
# MAGIC   bronze_processed_timestamp TIMESTAMP COMMENT 'Bronze layer processing time',
# MAGIC   silver_processed_timestamp TIMESTAMP COMMENT 'Silver layer processing time',
# MAGIC   gold_processed_timestamp TIMESTAMP COMMENT 'Gold layer processing time',
# MAGIC   
# MAGIC   processing_duration_seconds DOUBLE COMMENT 'Time from bronze to silver processing'
# MAGIC ) COMMENT 'Fact table containing document-level metrics and measurements'
# MAGIC TBLPROPERTIES ('quality' = 'gold', 'layer' = 'fact');
# MAGIC
# MAGIC -- Populate fact_document_metrics
# MAGIC INSERT OVERWRITE TABLE aichatbot.gold.fact_document_metrics
# MAGIC SELECT
# MAGIC   ROW_NUMBER() OVER (ORDER BY d.document_key) AS fact_key,
# MAGIC   d.document_key,
# MAGIC   CAST(DATE_FORMAT(s.silver_processed_at, 'yyyyMMdd') AS INT) AS processing_date_key,
# MAGIC   
# MAGIC   -- Metrics
# MAGIC   s.total_pages,
# MAGIC   s.total_elements,
# MAGIC   s.total_content_length,
# MAGIC   s.avg_content_length_per_element,
# MAGIC   ROUND(s.total_content_length / s.total_pages, 2) AS avg_content_length_per_page,
# MAGIC   
# MAGIC   -- Processing metadata
# MAGIC   s.bronze_processed_at AS bronze_processed_timestamp,
# MAGIC   s.silver_processed_at AS silver_processed_timestamp,
# MAGIC   CURRENT_TIMESTAMP() AS gold_processed_timestamp,
# MAGIC   
# MAGIC   ROUND((UNIX_TIMESTAMP(s.silver_processed_at) - UNIX_TIMESTAMP(s.bronze_processed_at)) / 60, 2) AS processing_duration_seconds
# MAGIC   
# MAGIC FROM aichatbot.silver.handbook_cleaned s
# MAGIC JOIN aichatbot.gold.dim_document d ON s.document_name = d.document_name;
# MAGIC
# MAGIC SELECT
# MAGIC   f.*,
# MAGIC   d.document_name,
# MAGIC   dt.full_date
# MAGIC FROM aichatbot.gold.fact_document_metrics f
# MAGIC JOIN aichatbot.gold.dim_document d ON f.document_key = d.document_key
# MAGIC JOIN aichatbot.gold.dim_date dt ON f.processing_date_key = dt.date_key;

# COMMAND ----------

# DBTITLE 1,Gold Layer Summary and Validation
# MAGIC %sql
# MAGIC -- ============================================================
# MAGIC -- GOLD LAYER SUMMARY AND VALIDATION
# MAGIC -- ============================================================
# MAGIC
# MAGIC SELECT '📊 GOLD LAYER SUMMARY' AS report_section;
# MAGIC
# MAGIC -- Table counts
# MAGIC SELECT
# MAGIC   'aichatbot.gold.dim_document' AS table_name,
# MAGIC   'Dimension' AS table_type,
# MAGIC   COUNT(*) AS record_count
# MAGIC FROM aichatbot.gold.dim_document
# MAGIC UNION ALL
# MAGIC SELECT
# MAGIC   'aichatbot.gold.dim_document_content' AS table_name,
# MAGIC   'Dimension' AS table_type,
# MAGIC   COUNT(*) AS record_count
# MAGIC FROM aichatbot.gold.dim_document_content
# MAGIC UNION ALL
# MAGIC SELECT
# MAGIC   'aichatbot.gold.dim_element_type' AS table_name,
# MAGIC   'Dimension' AS table_type,
# MAGIC   COUNT(*) AS record_count
# MAGIC FROM aichatbot.gold.dim_element_type
# MAGIC UNION ALL
# MAGIC SELECT
# MAGIC   'aichatbot.gold.dim_date' AS table_name,
# MAGIC   'Dimension' AS table_type,
# MAGIC   COUNT(*) AS record_count
# MAGIC FROM aichatbot.gold.dim_date
# MAGIC UNION ALL
# MAGIC SELECT
# MAGIC   'aichatbot.gold.fact_document_metrics' AS table_name,
# MAGIC   'Fact' AS table_type,
# MAGIC   COUNT(*) AS record_count
# MAGIC FROM aichatbot.gold.fact_document_metrics
# MAGIC UNION ALL
# MAGIC SELECT
# MAGIC   'aichatbot.gold.fact_element_content' AS table_name,
# MAGIC   'Fact' AS table_type,
# MAGIC   COUNT(*) AS record_count
# MAGIC FROM aichatbot.gold.fact_element_content
# MAGIC ORDER BY table_type, table_name;

# COMMAND ----------

# DBTITLE 1,Sample Analytics Query - Star Schema
# MAGIC %sql
# MAGIC -- ============================================================
# MAGIC -- SAMPLE ANALYTICS QUERY - STAR SCHEMA IN ACTION
# MAGIC -- ============================================================
# MAGIC -- Demonstrates how to use the star schema for analysis
# MAGIC
# MAGIC SELECT '📈 SAMPLE ANALYTICS QUERY' AS query_purpose;
# MAGIC
# MAGIC -- Document Content Analysis by Element Type
# MAGIC SELECT
# MAGIC   d.document_name,
# MAGIC   d.total_pages,
# MAGIC   dt.full_date AS processing_date,
# MAGIC   et.element_type_name,
# MAGIC   et.element_category,
# MAGIC   COUNT(fec.element_content_key) AS element_count,
# MAGIC   SUM(fec.text_length) AS total_characters,
# MAGIC   ROUND(AVG(fec.text_length), 2) AS avg_characters_per_element,
# MAGIC   ROUND(SUM(fec.text_length) * 100.0 / fdm.total_content_length, 2) AS pct_of_total_content
# MAGIC FROM aichatbot.gold.fact_element_content fec
# MAGIC JOIN aichatbot.gold.dim_document d 
# MAGIC   ON fec.document_key = d.document_key
# MAGIC JOIN aichatbot.gold.dim_element_type et 
# MAGIC   ON fec.element_type_key = et.element_type_key
# MAGIC JOIN aichatbot.gold.fact_document_metrics fdm 
# MAGIC   ON fec.document_key = fdm.document_key
# MAGIC JOIN aichatbot.gold.dim_date dt 
# MAGIC   ON fdm.processing_date_key = dt.date_key
# MAGIC WHERE fec.text_length > 0
# MAGIC GROUP BY 
# MAGIC   d.document_name,
# MAGIC   d.total_pages,
# MAGIC   dt.full_date,
# MAGIC   et.element_type_name,
# MAGIC   et.element_category,
# MAGIC   et.sort_order,
# MAGIC   fdm.total_content_length
# MAGIC ORDER BY 
# MAGIC   d.document_name,
# MAGIC   et.sort_order;

# COMMAND ----------

# DBTITLE 1,🚨 FIX: Create dim_document_content with Full Text
# MAGIC %sql
# MAGIC -- ============================================================
# MAGIC -- DIMENSION TABLE: dim_document_content (MISSING DATA FIX!)
# MAGIC -- ============================================================
# MAGIC -- Contains the actual document text content
# MAGIC -- CRITICAL: This was missing from the original Gold layer design!
# MAGIC
# MAGIC CREATE OR REPLACE TABLE aichatbot.gold.dim_document_content (
# MAGIC   content_key INT COMMENT 'Surrogate key for content record',
# MAGIC   document_key INT COMMENT 'Foreign key to dim_document',
# MAGIC   full_document_text STRING COMMENT 'Complete cleaned text content from document',
# MAGIC   content_hash STRING COMMENT 'MD5 hash of content for deduplication',
# MAGIC   word_count BIGINT COMMENT 'Estimated word count',
# MAGIC   character_count BIGINT COMMENT 'Total character count',
# MAGIC   created_at TIMESTAMP COMMENT 'When this content was created'
# MAGIC ) COMMENT 'Dimension table containing full document text content'
# MAGIC TBLPROPERTIES ('quality' = 'gold', 'layer' = 'dimension');
# MAGIC
# MAGIC -- Populate dim_document_content from Silver layer
# MAGIC INSERT OVERWRITE TABLE aichatbot.gold.dim_document_content
# MAGIC SELECT
# MAGIC   ROW_NUMBER() OVER (ORDER BY d.document_key) AS content_key,
# MAGIC   d.document_key,
# MAGIC   s.full_document_text,
# MAGIC   MD5(s.full_document_text) AS content_hash,
# MAGIC   SIZE(SPLIT(s.full_document_text, ' ')) AS word_count,
# MAGIC   LENGTH(s.full_document_text) AS character_count,
# MAGIC   CURRENT_TIMESTAMP() AS created_at
# MAGIC FROM aichatbot.silver.handbook_cleaned s
# MAGIC JOIN aichatbot.gold.dim_document d ON s.document_name = d.document_name;
# MAGIC
# MAGIC -- Verify the content was loaded
# MAGIC SELECT
# MAGIC   content_key,
# MAGIC   document_key,
# MAGIC   word_count,
# MAGIC   character_count,
# MAGIC   SUBSTRING(full_document_text, 1, 200) AS text_preview
# MAGIC FROM aichatbot.gold.dim_document_content;

# COMMAND ----------

# DBTITLE 1,🚨 FIX: Create fact_element_content with Element Text
# MAGIC %sql
# MAGIC -- ============================================================
# MAGIC -- FACT TABLE: fact_element_content (PRIMARY CONTENT TABLE)
# MAGIC -- ============================================================
# MAGIC -- Contains the actual text content of each element
# MAGIC -- This is the PRIMARY table for element-level data with actual text
# MAGIC
# MAGIC CREATE OR REPLACE TABLE aichatbot.gold.fact_element_content (
# MAGIC   element_content_key BIGINT COMMENT 'Surrogate key',
# MAGIC   document_key INT COMMENT 'Foreign key to dim_document',
# MAGIC   element_type_key INT COMMENT 'Foreign key to dim_element_type',
# MAGIC   page_number INT COMMENT 'Page number',
# MAGIC   element_position INT COMMENT 'Position in document',
# MAGIC   element_text STRING COMMENT 'Actual text content of the element',
# MAGIC   text_length INT COMMENT 'Character count',
# MAGIC   created_at TIMESTAMP COMMENT 'When this was created'
# MAGIC ) COMMENT 'Fact table containing actual element text content'
# MAGIC TBLPROPERTIES ('quality' = 'gold', 'layer' = 'fact');
# MAGIC
# MAGIC -- Populate from Bronze layer
# MAGIC INSERT OVERWRITE TABLE aichatbot.gold.fact_element_content
# MAGIC WITH bronze_elements AS (
# MAGIC   SELECT
# MAGIC     path,
# MAGIC     pos AS element_position,
# MAGIC     element,
# MAGIC     processed_at
# MAGIC   FROM aichatbot.bronze.handbook_pdf_parsed
# MAGIC   LATERAL VIEW posexplode(try_cast(parsed_content:document:elements AS ARRAY<VARIANT>)) AS pos, element
# MAGIC   WHERE try_cast(parsed_content:error_status AS STRING) IS NULL
# MAGIC )
# MAGIC SELECT
# MAGIC   ROW_NUMBER() OVER (ORDER BY d.document_key, be.element_position) AS element_content_key,
# MAGIC   d.document_key,
# MAGIC   COALESCE(et.element_type_key, 0) AS element_type_key,
# MAGIC   try_cast(be.element:page AS INT) AS page_number,
# MAGIC   be.element_position,
# MAGIC   try_cast(be.element:content AS STRING) AS element_text,
# MAGIC   LENGTH(try_cast(be.element:content AS STRING)) AS text_length,
# MAGIC   CURRENT_TIMESTAMP() AS created_at
# MAGIC FROM bronze_elements be
# MAGIC JOIN aichatbot.gold.dim_document d ON be.path = d.document_path
# MAGIC LEFT JOIN aichatbot.gold.dim_element_type et 
# MAGIC   ON try_cast(be.element:type AS STRING) = et.element_type_code
# MAGIC WHERE try_cast(be.element:content AS STRING) IS NOT NULL
# MAGIC   AND TRIM(try_cast(be.element:content AS STRING)) != '';
# MAGIC
# MAGIC -- Show sample with actual text
# MAGIC SELECT
# MAGIC   d.document_name,
# MAGIC   et.element_type_name,
# MAGIC   fec.page_number,
# MAGIC   fec.text_length,
# MAGIC   SUBSTRING(fec.element_text, 1, 100) AS text_preview
# MAGIC FROM aichatbot.gold.fact_element_content fec
# MAGIC JOIN aichatbot.gold.dim_document d ON fec.document_key = d.document_key
# MAGIC JOIN aichatbot.gold.dim_element_type et ON fec.element_type_key = et.element_type_key
# MAGIC ORDER BY fec.element_position
# MAGIC LIMIT 10;

# COMMAND ----------

# DBTITLE 1,🔍 Data Validation Report - Complete Audit
# MAGIC %sql
# MAGIC -- ============================================================
# MAGIC -- COMPREHENSIVE DATA VALIDATION REPORT
# MAGIC -- ============================================================
# MAGIC
# MAGIC SELECT '🔍 DATA VALIDATION REPORT' AS report_title;
# MAGIC
# MAGIC -- 1. Bronze Layer Validation
# MAGIC SELECT
# MAGIC   'Bronze Layer' AS layer,
# MAGIC   COUNT(*) AS documents,
# MAGIC   SUM(array_size(try_cast(parsed_content:document:elements AS ARRAY<VARIANT>))) AS total_elements,
# MAGIC   'Source of truth' AS status
# MAGIC FROM aichatbot.bronze.handbook_pdf_parsed;
# MAGIC
# MAGIC -- 2. Silver Layer Validation
# MAGIC SELECT
# MAGIC   'Silver Layer' AS layer,
# MAGIC   COUNT(*) AS documents,
# MAGIC   SUM(total_elements) AS total_elements,
# MAGIC   SUM(total_content_length) AS total_chars,
# MAGIC   CASE 
# MAGIC     WHEN SUM(CASE WHEN full_document_text IS NULL THEN 1 ELSE 0 END) = 0 
# MAGIC     THEN '✅ All text present'
# MAGIC     ELSE '❌ Missing text'
# MAGIC   END AS status
# MAGIC FROM aichatbot.silver.handbook_cleaned;
# MAGIC
# MAGIC -- 3. Gold Dimension Tables Validation
# MAGIC SELECT
# MAGIC   'Gold - dim_document' AS layer,
# MAGIC   COUNT(*) AS records,
# MAGIC   'Metadata only (no text)' AS status
# MAGIC FROM aichatbot.gold.dim_document
# MAGIC UNION ALL
# MAGIC SELECT
# MAGIC   'Gold - dim_document_content' AS layer,
# MAGIC   COUNT(*) AS records,
# MAGIC   CASE 
# MAGIC     WHEN COUNT(*) > 0 THEN '✅ Full text preserved'
# MAGIC     ELSE '❌ No records'
# MAGIC   END AS status
# MAGIC FROM aichatbot.gold.dim_document_content
# MAGIC UNION ALL
# MAGIC SELECT
# MAGIC   'Gold - dim_element_type' AS layer,
# MAGIC   COUNT(*) AS records,
# MAGIC   'Reference data' AS status
# MAGIC FROM aichatbot.gold.dim_element_type;
# MAGIC
# MAGIC -- 4. Gold Fact Tables Validation
# MAGIC SELECT
# MAGIC   'Gold - fact_document_metrics' AS layer,
# MAGIC   COUNT(*) AS records,
# MAGIC   SUM(total_content_length) AS total_chars,
# MAGIC   'Document-level metrics' AS status
# MAGIC FROM aichatbot.gold.fact_document_metrics
# MAGIC UNION ALL
# MAGIC SELECT
# MAGIC   'Gold - fact_element_content' AS layer,
# MAGIC   COUNT(*) AS records,
# MAGIC   SUM(text_length) AS total_chars,
# MAGIC   CASE 
# MAGIC     WHEN COUNT(*) > 0 THEN '✅ Element text preserved'
# MAGIC     ELSE '❌ No records'
# MAGIC   END AS status
# MAGIC FROM aichatbot.gold.fact_element_content;
# MAGIC
# MAGIC -- 5. Data Loss Check
# MAGIC SELECT
# MAGIC   '📊 Data Loss Analysis' AS check_type,
# MAGIC   b.bronze_chars,
# MAGIC   s.silver_chars,
# MAGIC   g.gold_chars,
# MAGIC   CASE 
# MAGIC     WHEN g.gold_chars >= s.silver_chars * 0.99 THEN '✅ No significant data loss'
# MAGIC     WHEN g.gold_chars >= s.silver_chars * 0.95 THEN '⚠️ Minor data loss (<5%)'
# MAGIC     ELSE '❌ SIGNIFICANT DATA LOSS'
# MAGIC   END AS assessment,
# MAGIC   ROUND(((s.silver_chars - g.gold_chars) * 100.0 / s.silver_chars), 2) AS pct_lost
# MAGIC FROM
# MAGIC   (SELECT SUM(array_size(try_cast(parsed_content:document:elements AS ARRAY<VARIANT>)) * 100) AS bronze_chars 
# MAGIC    FROM aichatbot.bronze.handbook_pdf_parsed) b,
# MAGIC   (SELECT SUM(total_content_length) AS silver_chars 
# MAGIC    FROM aichatbot.silver.handbook_cleaned) s,
# MAGIC   (SELECT SUM(text_length) AS gold_chars 
# MAGIC    FROM aichatbot.gold.fact_element_content) g;

# COMMAND ----------

# DBTITLE 1,✅ Final Gold Layer Summary - Complete with Text Content
# MAGIC %sql
# MAGIC -- ============================================================
# MAGIC -- FINAL GOLD LAYER SUMMARY - COMPLETE STAR SCHEMA
# MAGIC -- ============================================================
# MAGIC
# MAGIC SELECT '✅ COMPLETE GOLD LAYER STRUCTURE' AS summary_title;
# MAGIC
# MAGIC -- All Gold Tables with Record Counts
# MAGIC SELECT
# MAGIC   'Dimension Tables' AS category,
# MAGIC   'dim_document' AS table_name,
# MAGIC   COUNT(*) AS records,
# MAGIC   'Metadata (no text)' AS contains
# MAGIC FROM aichatbot.gold.dim_document
# MAGIC UNION ALL
# MAGIC SELECT
# MAGIC   'Dimension Tables' AS category,
# MAGIC   'dim_document_content' AS table_name,
# MAGIC   COUNT(*) AS records,
# MAGIC   '✅ FULL DOCUMENT TEXT' AS contains
# MAGIC FROM aichatbot.gold.dim_document_content
# MAGIC UNION ALL
# MAGIC SELECT
# MAGIC   'Dimension Tables' AS category,
# MAGIC   'dim_element_type' AS table_name,
# MAGIC   COUNT(*) AS records,
# MAGIC   'Reference data' AS contains
# MAGIC FROM aichatbot.gold.dim_element_type
# MAGIC UNION ALL
# MAGIC SELECT
# MAGIC   'Dimension Tables' AS category,
# MAGIC   'dim_date' AS table_name,
# MAGIC   COUNT(*) AS records,
# MAGIC   'Time dimension' AS contains
# MAGIC FROM aichatbot.gold.dim_date
# MAGIC UNION ALL
# MAGIC SELECT
# MAGIC   'Fact Tables' AS category,
# MAGIC   'fact_document_metrics' AS table_name,
# MAGIC   COUNT(*) AS records,
# MAGIC   'Document-level metrics' AS contains
# MAGIC FROM aichatbot.gold.fact_document_metrics
# MAGIC UNION ALL
# MAGIC SELECT
# MAGIC   'Fact Tables' AS category,
# MAGIC   'fact_element_content' AS table_name,
# MAGIC   COUNT(*) AS records,
# MAGIC   '✅ ELEMENT TEXT + METRICS' AS contains
# MAGIC FROM aichatbot.gold.fact_element_content
# MAGIC ORDER BY category, table_name;
# MAGIC
# MAGIC -- Sample Query: Get Full Document Text for Chatbot
# MAGIC SELECT
# MAGIC   '🤖 Sample: Full Text for Chatbot' AS query_purpose,
# MAGIC   d.document_name,
# MAGIC   dc.word_count,
# MAGIC   dc.character_count,
# MAGIC   SUBSTRING(dc.full_document_text, 1, 500) AS text_sample
# MAGIC FROM aichatbot.gold.dim_document d
# MAGIC JOIN aichatbot.gold.dim_document_content dc ON d.document_key = dc.document_key;
# MAGIC
# MAGIC -- Sample Query: Search Element Text
# MAGIC SELECT
# MAGIC   '🔍 Sample: Search Element Text' AS query_purpose,
# MAGIC   d.document_name,
# MAGIC   et.element_type_name,
# MAGIC   fec.page_number,
# MAGIC   fec.element_text
# MAGIC FROM aichatbot.gold.fact_element_content fec
# MAGIC JOIN aichatbot.gold.dim_document d ON fec.document_key = d.document_key
# MAGIC JOIN aichatbot.gold.dim_element_type et ON fec.element_type_key = et.element_type_key
# MAGIC WHERE LOWER(fec.element_text) LIKE '%teacher%'
# MAGIC LIMIT 10;