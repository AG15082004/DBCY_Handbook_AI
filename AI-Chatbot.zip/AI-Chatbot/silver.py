# Databricks notebook source
# DBTITLE 1,Configuration
# ============================================================
# SILVER LAYER - DATA CLEANING CONFIGURATION
# ============================================================

from pyspark.sql.functions import (
    col, explode, transform, concat_ws, regexp_replace, trim, lower,
    when, size, array_size, current_timestamp, lit, coalesce, length
)
from pyspark.sql.types import StringType

# Source and target configuration
BRONZE_TABLE = "aichatbot.bronze.handbook_pdf_parsed"
SILVER_TABLE = "aichatbot.silver.handbook_cleaned"

print(f"✅ Configuration loaded")
print(f"   Source: {BRONZE_TABLE}")
print(f"   Target: {SILVER_TABLE}")

# COMMAND ----------

# DBTITLE 1,Filter and Extract Valid Documents
# MAGIC %sql
# MAGIC -- ============================================================
# MAGIC -- STEP 2: FILTER OUT FAILED PARSES & EXTRACT VALID DOCUMENTS
# MAGIC -- ============================================================
# MAGIC
# MAGIC -- Filter out documents with parsing errors
# MAGIC CREATE OR REPLACE TEMPORARY VIEW valid_docs AS
# MAGIC SELECT
# MAGIC   path,
# MAGIC   file_size_bytes,
# MAGIC   file_modified_at,
# MAGIC   processed_at AS bronze_processed_at,
# MAGIC   parsed_content,
# MAGIC   size(try_cast(parsed_content:document:pages AS ARRAY<VARIANT>)) AS total_pages
# MAGIC FROM aichatbot.bronze.handbook_pdf_parsed
# MAGIC WHERE try_cast(parsed_content:error_status AS STRING) IS NULL;
# MAGIC
# MAGIC SELECT
# MAGIC   COUNT(*) AS valid_documents,
# MAGIC   (SELECT COUNT(*) FROM aichatbot.bronze.handbook_pdf_parsed) AS total_documents
# MAGIC FROM valid_docs;

# COMMAND ----------

# DBTITLE 1,Extract and Flatten Elements
# MAGIC %sql
# MAGIC -- ============================================================
# MAGIC -- STEP 3: EXTRACT AND FLATTEN DOCUMENT ELEMENTS
# MAGIC -- ============================================================
# MAGIC
# MAGIC -- Extract and explode elements from parsed content
# MAGIC CREATE OR REPLACE TEMPORARY VIEW elements_expanded AS
# MAGIC SELECT
# MAGIC   path,
# MAGIC   total_pages,
# MAGIC   bronze_processed_at,
# MAGIC   element
# MAGIC FROM valid_docs
# MAGIC LATERAL VIEW explode(try_cast(parsed_content:document:elements AS ARRAY<VARIANT>)) AS element;
# MAGIC
# MAGIC -- Show element type distribution
# MAGIC SELECT
# MAGIC   try_cast(element:type AS STRING) AS element_type,
# MAGIC   COUNT(*) AS count
# MAGIC FROM elements_expanded
# MAGIC GROUP BY element_type
# MAGIC ORDER BY count DESC;

# COMMAND ----------

# DBTITLE 1,Clean and Transform Elements
# MAGIC %sql
# MAGIC -- ============================================================
# MAGIC -- STEP 4: CLEAN AND TRANSFORM ELEMENT CONTENT
# MAGIC -- ============================================================
# MAGIC
# MAGIC -- Extract and clean element content
# MAGIC CREATE OR REPLACE TEMPORARY VIEW cleaned_elements AS
# MAGIC SELECT
# MAGIC   path,
# MAGIC   total_pages,
# MAGIC   bronze_processed_at,
# MAGIC   try_cast(element:type AS STRING) AS element_type,
# MAGIC   try_cast(element:content AS STRING) AS raw_content,
# MAGIC   try_cast(element:page AS INT) AS page_number,
# MAGIC   -- Clean content: remove extra whitespace and special characters
# MAGIC   TRIM(
# MAGIC     REGEXP_REPLACE(
# MAGIC       REGEXP_REPLACE(
# MAGIC         try_cast(element:content AS STRING),
# MAGIC         '\\s+', ' '
# MAGIC       ),
# MAGIC       '[\\x00-\\x08\\x0B\\x0C\\x0E-\\x1F\\x7F]', ''
# MAGIC     )
# MAGIC   ) AS cleaned_content
# MAGIC FROM elements_expanded;
# MAGIC
# MAGIC -- Add content length and check for empty content
# MAGIC CREATE OR REPLACE TEMPORARY VIEW cleaned_elements_with_metrics AS
# MAGIC SELECT
# MAGIC   *,
# MAGIC   LENGTH(cleaned_content) AS content_length,
# MAGIC   CASE
# MAGIC     WHEN cleaned_content IS NULL OR TRIM(cleaned_content) = '' THEN TRUE
# MAGIC     ELSE FALSE
# MAGIC   END AS is_empty
# MAGIC FROM cleaned_elements;
# MAGIC
# MAGIC -- Show sample
# MAGIC SELECT
# MAGIC   element_type,
# MAGIC   COUNT(*) AS count,
# MAGIC   SUM(CASE WHEN is_empty THEN 1 ELSE 0 END) AS empty_count,
# MAGIC   ROUND(AVG(content_length), 2) AS avg_length
# MAGIC FROM cleaned_elements_with_metrics
# MAGIC GROUP BY element_type
# MAGIC ORDER BY count DESC;

# COMMAND ----------

# DBTITLE 1,Remove Empty and Invalid Elements
# MAGIC %sql
# MAGIC -- ============================================================
# MAGIC -- STEP 5: REMOVE EMPTY AND INVALID ELEMENTS
# MAGIC -- ============================================================
# MAGIC
# MAGIC -- Filter out empty or very short content
# MAGIC CREATE OR REPLACE TEMPORARY VIEW filtered_elements AS
# MAGIC SELECT
# MAGIC   path,
# MAGIC   total_pages,
# MAGIC   bronze_processed_at,
# MAGIC   element_type,
# MAGIC   cleaned_content,
# MAGIC   page_number,
# MAGIC   content_length
# MAGIC FROM cleaned_elements_with_metrics
# MAGIC WHERE is_empty = FALSE
# MAGIC   AND content_length > 3;
# MAGIC
# MAGIC -- Show statistics
# MAGIC SELECT
# MAGIC   '✅ Valid elements after filtering' AS status,
# MAGIC   COUNT(*) AS count
# MAGIC FROM filtered_elements
# MAGIC UNION ALL
# MAGIC SELECT
# MAGIC   '🗑️ Elements removed' AS status,
# MAGIC   (SELECT COUNT(*) FROM cleaned_elements_with_metrics) - COUNT(*) AS count
# MAGIC FROM filtered_elements;

# COMMAND ----------

# DBTITLE 1,Create Aggregated Document Content
# MAGIC %sql
# MAGIC -- ============================================================
# MAGIC -- STEP 6: CREATE AGGREGATED DOCUMENT CONTENT
# MAGIC -- ============================================================
# MAGIC
# MAGIC -- Aggregate all elements by document
# MAGIC CREATE OR REPLACE TEMPORARY VIEW aggregated_docs AS
# MAGIC SELECT
# MAGIC   path,
# MAGIC   total_pages,
# MAGIC   bronze_processed_at,
# MAGIC   CONCAT_WS('\n\n', COLLECT_LIST(cleaned_content)) AS full_document_text,
# MAGIC   COUNT(*) AS total_elements,
# MAGIC   SUM(content_length) AS total_content_length
# MAGIC FROM filtered_elements
# MAGIC GROUP BY path, total_pages, bronze_processed_at;
# MAGIC
# MAGIC SELECT * FROM aggregated_docs;

# COMMAND ----------

# DBTITLE 1,Add Metadata and Create Silver Table
# MAGIC %sql
# MAGIC -- ============================================================
# MAGIC -- STEP 7: ADD METADATA AND CREATE SILVER TABLE
# MAGIC -- ============================================================
# MAGIC
# MAGIC -- Create the Silver table with all metadata
# MAGIC CREATE OR REPLACE TABLE aichatbot.silver.handbook_cleaned AS
# MAGIC SELECT
# MAGIC   REGEXP_EXTRACT(path, '([^/]+)$', 1) AS document_name,
# MAGIC   path,
# MAGIC   full_document_text,
# MAGIC   total_pages,
# MAGIC   total_elements,
# MAGIC   total_content_length,
# MAGIC   CAST(total_content_length / total_elements AS INT) AS avg_content_length_per_element,
# MAGIC   bronze_processed_at,
# MAGIC   CURRENT_TIMESTAMP() AS silver_processed_at
# MAGIC FROM aggregated_docs;
# MAGIC
# MAGIC -- Show the silver table
# MAGIC SELECT
# MAGIC   document_name,
# MAGIC   total_pages,
# MAGIC   total_elements,
# MAGIC   total_content_length,
# MAGIC   avg_content_length_per_element,
# MAGIC   silver_processed_at
# MAGIC FROM aichatbot.silver.handbook_cleaned;

# COMMAND ----------

# DBTITLE 1,Data Quality Checks
# MAGIC %sql
# MAGIC -- ============================================================
# MAGIC -- STEP 8: DATA QUALITY CHECKS
# MAGIC -- ============================================================
# MAGIC
# MAGIC SELECT '🔍 DATA QUALITY REPORT' AS report_section;
# MAGIC
# MAGIC -- Check 1: Record count
# MAGIC SELECT
# MAGIC   '✅ Total records' AS check_type,
# MAGIC   COUNT(*) AS count
# MAGIC FROM aichatbot.silver.handbook_cleaned;
# MAGIC
# MAGIC -- Check 2: Null checks
# MAGIC SELECT
# MAGIC   '📋 Null value checks' AS check_type,
# MAGIC   SUM(CASE WHEN document_name IS NULL THEN 1 ELSE 0 END) AS null_document_name,
# MAGIC   SUM(CASE WHEN full_document_text IS NULL THEN 1 ELSE 0 END) AS null_full_text,
# MAGIC   SUM(CASE WHEN total_pages IS NULL THEN 1 ELSE 0 END) AS null_total_pages
# MAGIC FROM aichatbot.silver.handbook_cleaned;
# MAGIC
# MAGIC -- Check 3: Content statistics
# MAGIC SELECT
# MAGIC   '📊 Content statistics' AS check_type,
# MAGIC   ROUND(AVG(total_pages), 2) AS avg_pages,
# MAGIC   ROUND(AVG(total_elements), 2) AS avg_elements,
# MAGIC   ROUND(AVG(total_content_length), 2) AS avg_content_length,
# MAGIC   MIN(total_content_length) AS min_content_length,
# MAGIC   MAX(total_content_length) AS max_content_length
# MAGIC FROM aichatbot.silver.handbook_cleaned;