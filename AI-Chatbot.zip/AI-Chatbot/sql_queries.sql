-- Databricks notebook source
drop table if exists aichatbot.bronze.handbook_by_page;
drop table if exists aichatbot.bronze.handbook_content;
drop table if exists aichatbot.bronze.handbook_knowledge_base;
drop table if exists aichatbot.bronze.handbook_topics;

-- COMMAND ----------

select * from aichatbot.bronze.handbook_pdf_parsed;

-- COMMAND ----------

select count(*) from aichatbot.gold.vector_source_chunks;

-- COMMAND ----------

select (*) from aichatbot.gold.vector_source_chunks;